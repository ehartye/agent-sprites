# Marmalade groom: editable projects

Open one part-XX.project.json in agent-sprites. Each independently editable part contains 40 consecutive native 384x256 frames, exact 50ms holds and a one-shot two-second tag. The segments are deliberately not advertised as seamless loops. Cell coordinates and tag refs are remapped; frame names, shapes, normal/material metadata and layer coordinates remain unchanged.

Play parts in numeric order for the complete 6-second short. The paired atlas and full GIF are separate downloads. project.json.gz preserves the complete native export for custody/CLI use; its unpacked size exceeds the browser editor import limit.
